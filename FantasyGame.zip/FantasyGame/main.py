from src.core.game import Game
from src.scenes.menu_scene import MenuScene

if __name__ == "__main__":            
    game = Game()
    menu = MenuScene(game)
    game.scene_manager.set_scene(menu)
    game.run()
  






