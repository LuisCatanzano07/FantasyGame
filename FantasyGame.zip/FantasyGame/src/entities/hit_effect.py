import pygame
import os

class HitEffect(pygame.sprite.Sprite):
    """Efecto visual cuando el jugador golpea a un enemigo"""
    LIFETIME = 10  # Duración del efecto en frames

    def __init__(self, x, y):
        super().__init__()
        
        self.image = self.load_sprite()
        self.rect = self.image.get_rect(center=(x, y))
        self.lifetime = self.LIFETIME
    
    def load_sprite(self):
        """Carga el sprite del efecto de impacto"""
        sprite_path = os.path.join("assets", "sprites", "effects", "hit_effect.png")
        image = pygame.image.load(sprite_path).convert_alpha()
        return pygame.transform.scale(image, (50, 50))
    
    def update(self):
        """Reducir la duración del efecto y eliminarlo después de un tiempo"""
        self.lifetime -= 1
        if self.lifetime <= 0:
            self.kill()

