import pygame
import random
from src.entities.enemy.movement import move_enemy

class EnemyBehavior:
    """Clase base para los comportamientos de enemigos"""
    def update(self, enemy, player):
        print(f"Advertencia: {self.__class__.__name__} no implementa un método `update` válido.")
        return 0, 0, "idle"

class RandomMovement(EnemyBehavior):
    """Movimiento aleatorio con colisiones"""
    def __init__(self):
        self.change_time = random.randint(30, 100)
        self.randomize_direction()

    def randomize_direction(self):
        """Cambia la dirección aleatoriamente"""
        directions = ["up", "down", "left", "right"]
        self.direction = random.choice(directions)
        self.direction_vector = pygame.Vector2(0, 0)

        if self.direction == "up":
            self.direction_vector = pygame.Vector2(0, -1)
        elif self.direction == "down":
            self.direction_vector = pygame.Vector2(0, 1)
        elif self.direction == "left":
            self.direction_vector = pygame.Vector2(-1, 0)
        elif self.direction == "right":
            self.direction_vector = pygame.Vector2(1, 0)

    def update(self, enemy, player):
        if self.change_time <= 0:
            self.randomize_direction()
            self.change_time = random.randint(30, 100)

        dx, dy = self.direction_vector.x * enemy.speed, self.direction_vector.y * enemy.speed
        move_enemy(enemy, dx, dy, self.direction)
        self.change_time -= 1
        return dx, dy, self.direction

class ChasePlayer(EnemyBehavior):
    """Enemigo que persigue al jugador respetando colisiones"""
    def update(self, enemy, player):
        direction_vector = pygame.Vector2(player.rect.x - enemy.rect.x, player.rect.y - enemy.rect.y)
        if direction_vector.length() > 0:
            direction_vector = direction_vector.normalize()

        dx, dy = round(direction_vector.x * enemy.speed), round(direction_vector.y * enemy.speed)
        if not enemy.check_collision(dx, dy):
            enemy.rect.x += dx
            enemy.rect.y += dy
        else:
            dx, dy = 0, 0

        direction = "left" if dx < 0 else "right" if dx > 0 else "up" if dy < 0 else "down"
        return dx, dy, direction

class PatrolBehavior(EnemyBehavior):
    """Enemigo que patrulla una ruta predefinida"""
    def __init__(self, patrol_points):
        self.patrol_points = patrol_points
        self.current_point_index = 0

    def update(self, enemy, player):
        if not self.patrol_points:
            return 0, 0, "idle"

        target_point = self.patrol_points[self.current_point_index]
        direction_vector = pygame.Vector2(target_point[0] - enemy.rect.x, target_point[1] - enemy.rect.y)
        if direction_vector.length() > 0:
            direction_vector = direction_vector.normalize()

        dx, dy = round(direction_vector.x * enemy.speed), round(direction_vector.y * enemy.speed)
        direction = "right" if dx > 0 else "left" if dx < 0 else "down" if dy > 0 else "up"

        if not enemy.check_collision(dx, dy):
            move_enemy(enemy, dx, dy, direction)
        else:
            self.current_point_index = (self.current_point_index + 1) % len(self.patrol_points)

        return dx, dy, direction

