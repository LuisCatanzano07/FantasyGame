import pygame
import os

def load_enemy_sounds():
    """Carga los sonidos del enemigo."""
    sounds = {
        "hit": pygame.mixer.Sound(os.path.join("assets", "sounds", "impact_sound.wav")),
        "death": pygame.mixer.Sound(os.path.join("assets", "sounds", "enemy_death_sound.wav"))
    }
    return sounds
