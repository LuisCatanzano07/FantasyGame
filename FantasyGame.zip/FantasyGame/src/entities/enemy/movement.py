import pygame

def move_enemy(enemy, dx, dy, direction):
    """Mueve al enemigo en la dirección dada respetando colisiones."""
    if not enemy.check_collision(dx, dy):
        enemy.rect.x += dx
        enemy.rect.y += dy
        enemy.direction = direction
