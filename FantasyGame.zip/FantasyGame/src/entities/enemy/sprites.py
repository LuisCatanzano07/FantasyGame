import pygame
import os

def load_enemy_sprites():
    """Carga los sprites del enemigo."""
    base_path = os.path.join("assets", "sprites", "enemigos")
    sprites = {
        "idle": pygame.image.load(os.path.join(base_path, "Esqueleton_idle.png")).convert_alpha(),
        "walk_left": [pygame.image.load(os.path.join(base_path, f"Esqueleton_walk_left{i}.png")).convert_alpha() for i in range(1, 11)],
        "walk_right": [pygame.image.load(os.path.join(base_path, f"Esqueleton_walk_right{i}.png")).convert_alpha() for i in range(1, 11)],
        "walk_up": [pygame.image.load(os.path.join(base_path, f"Esqueleton_walk_up{i}.png")).convert_alpha() for i in range(1, 11)],
        "walk_down": [pygame.image.load(os.path.join(base_path, f"Esqueleton_walk_down{i}.png")).convert_alpha() for i in range(1, 11)]
    }
    return sprites
