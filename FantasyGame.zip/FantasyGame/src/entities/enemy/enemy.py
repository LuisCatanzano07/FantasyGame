import pygame
from src.entities.enemy.behaviors import RandomMovement, ChasePlayer, PatrolBehavior
from src.entities.enemy.movement import move_enemy
from src.entities.enemy.sprites import load_enemy_sprites
from src.entities.enemy.sounds import load_enemy_sounds
from src.entities.hit_effect import HitEffect

class Enemy(pygame.sprite.Sprite):
    """Clase base para los enemigos"""
    def __init__(self, x, y, behavior, solid_tiles):
        super().__init__()
        
        # Cargar los sprites y sonidos del enemigo
        self.sprites = load_enemy_sprites()
        self.sounds = load_enemy_sounds()
        
        self.image = self.sprites["idle"]
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)
        self.speed = 2
        self.behavior = behavior  # Comportamiento del enemigo
        self.solid_tiles = solid_tiles
        
        # Vida del enemigo
        self.health = 2
    
    def take_damage(self, effects_group):
        """Reduce la vida del enemigo y muestra un efecto de impacto"""
        self.health -= 1
        print(f"¡El enemigo ha sido golpeado! Vida restante: {self.health}")
        
        if effects_group is not None:
            effect = HitEffect(self.rect.centerx, self.rect.centery)
            effects_group.add(effect)
        
        if self.health <= 0:
            self.sounds["death"].play()
            self.kill()
    
    def check_collision(self, dx, dy):
        """Verifica si el enemigo colisiona con un tile sólido"""
        new_rect = self.rect.move(dx, dy)
        for tile in self.solid_tiles:
            if new_rect.colliderect(tile.rect):
                return True  # Hay colisión
        return False  # No hay colisión
    
    def update(self, player):
        """Actualizar la IA del enemigo basado en su comportamiento"""
        dx, dy, direction = self.behavior.update(self, player)
        move_enemy(self, dx, dy, direction)







