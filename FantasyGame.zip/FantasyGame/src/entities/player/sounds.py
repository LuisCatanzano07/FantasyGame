import pygame
import os

def load_player_sounds():
    """Carga los sonidos del jugador."""
    sounds = {
        "attack": pygame.mixer.Sound(os.path.join("assets", "sounds", "hit_sound.wav")),
        "damage": pygame.mixer.Sound(os.path.join("assets", "sounds", "player_damage_sound.wav"))
    }
    return sounds
