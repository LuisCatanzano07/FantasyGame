import pygame
import os

def load_player_sprites():
    """Carga los sprites del jugador."""
    base_path = os.path.join("assets", "sprites", "personajes")
    sprites = {
        "idle": pygame.image.load(os.path.join(base_path, "jugador_idle.png")).convert_alpha(),
        "walk_left": [pygame.image.load(os.path.join(base_path, f"jugador_walk_left{i}.png")).convert_alpha() for i in range(1, 8)],
        "walk_right": [pygame.image.load(os.path.join(base_path, f"jugador_walk_right{i}.png")).convert_alpha() for i in range(1, 8)],
        "walk_up": [pygame.image.load(os.path.join(base_path, f"jugador_walk_up{i}.png")).convert_alpha() for i in range(1, 8)],
        "walk_down": [pygame.image.load(os.path.join(base_path, f"jugador_walk_down{i}.png")).convert_alpha() for i in range(1, 8)],
        "attack_left": pygame.image.load(os.path.join(base_path, "jugador_attack_left.png")).convert_alpha(),
        "attack_right": pygame.image.load(os.path.join(base_path, "jugador_attack_right.png")).convert_alpha(),
        "attack_up": pygame.image.load(os.path.join(base_path, "jugador_attack_up.png")).convert_alpha(),
        "attack_down": pygame.image.load(os.path.join(base_path, "jugador_attack_down.png")).convert_alpha()
    }
    return sprites
