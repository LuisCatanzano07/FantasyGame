import pygame
from src.entities.projectile import Projectile

def use_ability(player):
    """Dispara un proyectil basado en la habilidad activa."""
    if not player.active_ability:
        return  # No hacer nada si no hay habilidad activa

    projectile = Projectile(player.rect.centerx, player.rect.centery, player.direction, player.active_ability)
    player.projectiles.add(projectile)
    print(f"Disparando {player.active_ability} en dirección {player.direction}")

def change_ability(player, key):
    """Cambia la habilidad activa del jugador según la tecla presionada."""
    abilities = {
        pygame.K_1: "fire_ray",
        pygame.K_2: "ice_ray",
        pygame.K_3: "lightning_ray",
        pygame.K_4: "dark_ray",
        pygame.K_5: "wind_ray",
        pygame.K_6: "plasma_ray",
        pygame.K_7: "gravity_ray",
        pygame.K_8: "earth_ray",
        pygame.K_9: "arcane_ray",
        pygame.K_0: None  # Desactiva la habilidad
    }
    
    if key in abilities:
        player.active_ability = abilities[key]
        print(f"Habilidad activada: {player.active_ability if player.active_ability else 'ninguna'}")

def update_projectiles(player):
    """Actualiza la posición de los proyectiles en el juego."""
    for projectile in player.projectiles:
        projectile.update()


