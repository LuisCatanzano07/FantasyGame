import pygame
from src.entities.player.sprites import load_player_sprites
from src.entities.player.sounds import load_player_sounds
from src.entities.player.movement import move_player
from src.entities.player.abilities import use_ability, change_ability

class Player(pygame.sprite.Sprite):
    """Clase del jugador con animaciones y sonidos"""
    def __init__(self, x, y, solid_tiles):
        super().__init__()
        
        # Cargar sprites y sonidos
        self.sprites = load_player_sprites()
        self.sounds = load_player_sounds()
        
        self.image = self.sprites["idle"]
        self.rect = self.image.get_rect(topleft=(x, y))
        self.speed = 10
        self.solid_tiles = solid_tiles
        self.direction = "idle"
        self.animation_index = 0
        self.animation_speed = 0.15
        self.frame_counter = 0
        self.moving = False
        
        # Variables de ataque y habilidades
        self.attacking = False
        self.attack_timer = 0
        self.active_ability = None
        self.projectiles = pygame.sprite.Group()
        
        # Vida del jugador
        self.health = 3
        self.invulnerable = False
        self.invulnerable_timer = 0
        
    def use_ability(self):
        """Dispara un proyectil basado en la habilidad activa"""
        use_ability(self)
    
    def check_collision(self, dx, dy):
        """Verifica colisión con tiles sólidos"""
        new_rect = self.rect.move(dx, dy)
        return any(new_rect.colliderect(tile.rect) for tile in self.solid_tiles)
    
    def handle_input(self):
        """Maneja la entrada del jugador y actualiza la dirección y habilidades"""
        keys = pygame.key.get_pressed()
        dx, dy = 0, 0
        self.moving = False
        
        if keys[pygame.K_LEFT]:
            dx = -self.speed
            self.direction = "walk_left"
            self.moving = True
        elif keys[pygame.K_RIGHT]:
            dx = self.speed
            self.direction = "walk_right"
            self.moving = True
        elif keys[pygame.K_UP]:
            dy = -self.speed
            self.direction = "walk_up"
            self.moving = True
        elif keys[pygame.K_DOWN]:
            dy = self.speed
            self.direction = "walk_down"
            self.moving = True
        else:
            self.direction = "idle"
        
        move_player(self, dx, dy)
        
        for num in range(1, 10):
            if keys[getattr(pygame, f'K_{num}')]:
                change_ability(self, getattr(pygame, f'K_{num}'))
        
        if keys[pygame.K_0]:
            self.active_ability = None
    
    def update(self):
        """Actualiza la lógica del jugador"""
        self.handle_input()
        self.projectiles.update()
        
        if self.attacking:
            self.attack_timer -= 1
            if self.attack_timer <= 0:
                self.attacking = False
        else:
            self.update_animation()
    
    def update_animation(self):
        """Maneja la animación del jugador"""
        if self.moving and self.direction in self.sprites and isinstance(self.sprites[self.direction], list):
            self.frame_counter += self.animation_speed
            if self.frame_counter >= len(self.sprites[self.direction]):
                self.frame_counter = 0
            self.image = self.sprites[self.direction][int(self.frame_counter)]
        else:
            self.image = self.sprites["idle"]
    
    def take_damage(self):
        """Reduce la vida del jugador y reproduce sonido"""
        if not self.invulnerable:
            self.health -= 1
            self.sounds["damage"].play()
            print(f"¡El jugador ha sido golpeado! Vida restante: {self.health}")
            self.invulnerable = True
            self.invulnerable_timer = 60
    
    def draw_health_bar(self, screen):
        """Dibuja la barra de vida del jugador en pantalla"""
        bar_width = 150
        bar_height = 20
        fill = (self.health / 3) * bar_width
        border_color = (255, 255, 255)
        fill_color = (255, 0, 0)
        
        bar_x = 20
        bar_y = 20
        
        pygame.draw.rect(screen, border_color, (bar_x, bar_y, bar_width, bar_height), 2)
        pygame.draw.rect(screen, fill_color, (bar_x, bar_y, fill, bar_height))
    
    def attack(self, enemies, effects_group):
        """Realiza un ataque y reproduce sonido"""
        if not self.attacking:
            self.attacking = True
            self.attack_timer = 10
            self.sounds["attack"].play()
            
            if self.direction.startswith("walk_"):
                self.image = self.sprites[self.direction.replace("walk", "attack")]
            
            attack_range = pygame.Rect(self.rect.x - 20, self.rect.y - 20, self.rect.width + 40, self.rect.height + 40)
            
            for enemy in enemies:
                if attack_range.colliderect(enemy.rect):
                    enemy.take_damage(effects_group)
                    print("¡Golpeaste a un enemigo!")
    
    def update_projectiles(player):
        """Actualiza la posición de los proyectiles en el juego."""
        for projectile in player.projectiles:
            projectile.update()










