import pygame

def move_player(player, dx, dy):
    """Mueve al jugador respetando colisiones."""
    if not player.check_collision(dx, dy):
        player.rect.x += dx
        player.rect.y += dy
