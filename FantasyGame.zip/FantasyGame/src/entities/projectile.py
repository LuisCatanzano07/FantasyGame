import pygame
import os

class Projectile(pygame.sprite.Sprite):
    """Clase para proyectiles de habilidades"""
    def __init__(self, x, y, direction, ability_type):
        super().__init__()

        self.speed = 15
        self.direction = direction if direction != "idle" else "right"  # Evitar proyectiles sin dirección
        self.ability_type = ability_type

        # Cargar la imagen de la habilidad
        image_path = os.path.join("assets", "sprites", "habilidades", f"{ability_type}.png")
        
        if os.path.exists(image_path):
            self.image = pygame.image.load(image_path).convert_alpha()
        else:
            print(f"⚠️ Advertencia: No se encontró {image_path}. Usando imagen por defecto.")
            self.image = pygame.Surface((40, 40), pygame.SRCALPHA)
            self.image.fill((255, 255, 255, 128))

        self.rect = self.image.get_rect(center=(x, y))

    def update(self):
        """Mueve el proyectil en la dirección deseada"""
        if self.direction == "left":
            self.rect.x -= self.speed
        elif self.direction == "right":
            self.rect.x += self.speed
        elif self.direction == "up":
            self.rect.y -= self.speed
        elif self.direction == "down":
            self.rect.y += self.speed

        # Eliminar proyectil si sale de la pantalla
        screen_width = 800  # Ajustar según el tamaño de la pantalla
        screen_height = 600

        if self.rect.right < 0 or self.rect.left > screen_width or \
           self.rect.bottom < 0 or self.rect.top > screen_height:
            print(f"Proyectil {self.ability_type} eliminado por salir de pantalla.")
            self.kill()  # Eliminar proyectil al salir de la pantalla

        print(f"Proyectil {self.ability_type} en posición ({self.rect.x}, {self.rect.y})")  # Debug





