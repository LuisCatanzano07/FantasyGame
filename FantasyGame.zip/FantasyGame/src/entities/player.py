import pygame
import os

class Player(pygame.sprite.Sprite):
    """Clase del jugador con animaciones y sonidos"""
    def __init__(self, x, y, solid_tiles):
        super().__init__()
        
        # Cargar recursos
        self.sprites = self.load_sprites()
        self.sounds = self.load_sounds()

        # Configuración inicial
        self.image = self.sprites["idle"]
        self.rect = self.image.get_rect(topleft=(x, y))
        self.speed = 10
        self.solid_tiles = solid_tiles
        self.direction = "idle"
        self.animation_index = 0
        self.animation_speed = 0.15
        self.frame_counter = 0
        self.moving = False
        
        # Variables de ataque
        self.attacking = False
        self.attack_timer = 0
        
        # Vida del jugador
        self.health = 3
        self.invulnerable = False
        self.invulnerable_timer = 0
    
    def load_sprites(self):
        """Carga los sprites del jugador"""
        base_path = os.path.join("assets", "sprites", "personajes")
        sprites = {
            "idle": pygame.image.load(os.path.join(base_path, "jugador_idle.png")).convert_alpha(),
            "walk_left": [pygame.image.load(os.path.join(base_path, f"jugador_walk_left{i}.png")).convert_alpha() for i in range(1, 8)],
            "walk_right": [pygame.image.load(os.path.join(base_path, f"jugador_walk_right{i}.png")).convert_alpha() for i in range(1, 8)],
            "walk_up": [pygame.image.load(os.path.join(base_path, f"jugador_walk_up{i}.png")).convert_alpha() for i in range(1, 8)],
            "walk_down": [pygame.image.load(os.path.join(base_path, f"jugador_walk_down{i}.png")).convert_alpha() for i in range(1, 8)],
            "attack_left": pygame.image.load(os.path.join(base_path, "jugador_attack_left.png")).convert_alpha(),
            "attack_right": pygame.image.load(os.path.join(base_path, "jugador_attack_right.png")).convert_alpha(),
            "attack_up": pygame.image.load(os.path.join(base_path, "jugador_attack_up.png")).convert_alpha(),
            "attack_down": pygame.image.load(os.path.join(base_path, "jugador_attack_down.png")).convert_alpha()
        }
        
        for key, images in sprites.items():
            if isinstance(images, list):
                sprites[key] = [pygame.transform.scale(img, (50, 50)) for img in images]
            else:
                sprites[key] = pygame.transform.scale(images, (50, 50))
        
        return sprites       
      
    def load_sounds(self):
        """Carga los sonidos del jugador"""
        sounds = {
            "attack": pygame.mixer.Sound(os.path.join("assets", "sounds", "hit_sound.wav")),
            "damage": pygame.mixer.Sound(os.path.join("assets", "sounds", "player_damage_sound.wav"))
        }
        
        for sound in sounds.values():
            sound.set_volume(0.5)
        
        return sounds

    def take_damage(self):
        """Reduce la vida del jugador y reproduce sonido"""
        if not self.invulnerable:
            self.health -= 1
            self.sounds["damage"].play()
            print(f"¡El jugador ha sido golpeado! Vida restante: {self.health}")
            self.invulnerable = True
            self.invulnerable_timer = 60    
    
    def draw_health_bar(self, screen):
        """Dibuja la barra de vida del jugador en pantalla"""
        bar_width = 150
        bar_height = 20
        fill = (self.health / 3) * bar_width  # Ajustar la proporción de vida restante
        border_color = (255, 255, 255)  # Blanco
        fill_color = (255, 0, 0)  # Rojo

        bar_x = 20  # Posición en pantalla
        bar_y = 20

        pygame.draw.rect(screen, border_color, (bar_x, bar_y, bar_width, bar_height), 2)  # Borde
        pygame.draw.rect(screen, fill_color, (bar_x, bar_y, fill, bar_height))  # Barra de vida        
    
    def attack(self, enemies, effects_group):
        """Realiza un ataque y reproduce sonido"""
        if not self.attacking:
            self.attacking = True
            self.attack_timer = 10
            self.sounds["attack"].play()
            
            if self.direction.startswith("walk_"):
                self.image = self.sprites[self.direction.replace("walk", "attack")]

            attack_range = self.get_attack_range()

            for enemy in enemies:
                if attack_range.colliderect(enemy.rect):
                    enemy.take_damage(effects_group)
                    print("¡Golpeaste a un enemigo!")

                    # Agregar efecto de impacto
                    if effects_group is not None:
                        from src.entities.hit_effect import HitEffect
                        effect = HitEffect(enemy.rect.centerx, enemy.rect.centery)
                        effects_group.add(effect)
    
    def get_attack_range(self):
        """Devuelve el área de ataque del jugador"""
        return pygame.Rect(self.rect.x - 20, self.rect.y - 20, self.rect.width + 40, self.rect.height + 40)
    
    def check_collision(self, dx, dy):
        """Verifica colisión con tiles sólidos"""
        new_rect = self.rect.move(dx, dy)
        return any(new_rect.colliderect(tile.rect) for tile in self.solid_tiles)
    
    def handle_input(self):
        """Maneja la entrada del jugador y actualiza la dirección"""
        keys = pygame.key.get_pressed()
        dx, dy = 0, 0
        self.moving = False

        if keys[pygame.K_LEFT]:
            dx = -self.speed
            self.direction = "walk_left"
            self.moving = True
        elif keys[pygame.K_RIGHT]:
            dx = self.speed
            self.direction = "walk_right"
            self.moving = True
        elif keys[pygame.K_UP]:
            dy = -self.speed
            self.direction = "walk_up"
            self.moving = True
        elif keys[pygame.K_DOWN]:
            dy = self.speed
            self.direction = "walk_down"
            self.moving = True
        else:
            self.direction = "idle"

        if not self.check_collision(dx, dy):
            self.rect.x += dx
            self.rect.y += dy
    
    def update(self):
        """Actualiza la lógica del jugador"""
        self.handle_input()
        
        if self.attacking:
            self.attack_timer -= 1
            if self.attack_timer <= 0:
                self.attacking = False
        else:
            self.update_animation()
    
    def update_animation(self):
        """Maneja la animación del jugador"""
        if self.moving and self.direction in self.sprites and isinstance(self.sprites[self.direction], list):
            self.frame_counter += self.animation_speed
            if self.frame_counter >= len(self.sprites[self.direction]):
                self.frame_counter = 0
            self.image = self.sprites[self.direction][int(self.frame_counter)]
        else:
            self.image = self.sprites["idle"]








