import pygame
import os
from src.entities.tile import Tile

class Map:
    """Clase para manejar el mapa del juego"""
    TILE_SIZE = 100  # Antes era 50, ahora es 100 píxeles
    TILE_IMAGES = {
        0: os.path.join("assets", "tiles", "suelo.png"),  # Suelo (sin colisión)
        1: os.path.join("assets", "tiles", "pared.png")   # Pared (colisión)
    }
    
    def __init__(self):
        self.tiles = pygame.sprite.Group()
        self.solid_tiles = []  # Lista de tiles sólidos para colisiones
        self.map_data = [
            [1, 1, 1, 1, 1, 1, 1, 1],
            [1, 0, 0, 0, 0, 0, 0, 1],
            [1, 0, 1, 1, 1, 1, 0, 1],
            [1, 0, 1, 0, 0, 1, 0, 1],
            [1, 0, 1, 0, 1, 1, 0, 1],
            [1, 0, 0, 0, 0, 0, 0, 1],
            [1, 1, 1, 1, 1, 1, 1, 1]
        ]
        
        self.load_tiles()
    
    def load_tiles(self):
        """Carga y construye los tiles del mapa"""
        for row_index, row in enumerate(self.map_data):
            for col_index, tile_type in enumerate(row):
                x = col_index * self.TILE_SIZE
                y = row_index * self.TILE_SIZE
                is_solid = (tile_type == 1)
                tile = Tile(x, y, self.TILE_IMAGES[tile_type], is_solid)
                self.tiles.add(tile)
                if is_solid:
                    self.solid_tiles.append(tile)
    
    def draw(self, screen):
        """Dibujar el mapa en la pantalla"""
        self.tiles.draw(screen)




