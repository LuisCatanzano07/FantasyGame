import pygame
import os

class Tile(pygame.sprite.Sprite):
    """Clase que representa una baldosa del mapa"""
    TILE_SIZE = 100  # Tamaño de cada tile
    
    def __init__(self, x, y, image_path, is_solid=False):
        super().__init__()
        self.image = self.load_image(image_path)
        self.rect = self.image.get_rect(topleft=(x, y))
        self.is_solid = is_solid  # Indica si el jugador puede colisionar con este tile
    
    def load_image(self, image_path):
        """Carga y escala la imagen del tile"""
        image = pygame.image.load(image_path).convert_alpha()
        return pygame.transform.scale(image, (self.TILE_SIZE, self.TILE_SIZE))

