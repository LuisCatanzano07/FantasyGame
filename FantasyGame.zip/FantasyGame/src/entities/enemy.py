import pygame
import os
from src.entities.hit_effect import HitEffect

class Enemy(pygame.sprite.Sprite):
    """Clase base para los enemigos"""
    def __init__(self, x, y, behavior, solid_tiles):
        super().__init__()

        # Cargar los sprites de animación
        self.sprites = self.load_sprites()
        self.image = self.sprites["idle"]
        self.rect = self.image.get_rect(topleft=(x, y))

        self.speed = 2
        self.direction = "down"  # Dirección inicial por defecto

        self.animation_index = 0
        self.animation_speed = 0.15
        self.frame_counter = 0

        self.behavior = behavior  # Comportamiento del enemigo
        self.solid_tiles = solid_tiles  # Tiles sólidos para colisión

        # Vida del enemigo
        self.health = 2

        # Cargar sonidos
        self.hit_sound = pygame.mixer.Sound(os.path.join("assets", "sounds", "impact_sound.wav"))
        self.death_sound = pygame.mixer.Sound(os.path.join("assets", "sounds", "enemy_death_sound.wav"))

        self.hit_sound.set_volume(0.5)
        self.death_sound.set_volume(0.5)
    
    def load_sprites(self):
        """Carga los sprites de animación del enemigo"""
        base_path = os.path.join("assets", "sprites", "enemigos")
        sprites = {
            "idle": pygame.image.load(os.path.join(base_path, "Esqueleton_idle.png")).convert_alpha(),
            "walk_up": [pygame.image.load(os.path.join(base_path, f"Esqueleton_walk_up{i}.png")).convert_alpha() for i in range(1, 11)],
            "walk_down": [pygame.image.load(os.path.join(base_path, f"Esqueleton_walk_down{i}.png")).convert_alpha() for i in range(1, 11)],
            "walk_left": [pygame.image.load(os.path.join(base_path, f"Esqueleton_walk_left{i}.png")).convert_alpha() for i in range(1, 11)],
            "walk_right": [pygame.image.load(os.path.join(base_path, f"Esqueleton_walk_right{i}.png")).convert_alpha() for i in range(1, 11)],
        }

        for key, images in sprites.items():
            if isinstance(images, list):
                sprites[key] = [pygame.transform.scale(img, (50, 50)) for img in images]
            else:
                sprites[key] = pygame.transform.scale(images, (50, 50))

        return sprites
    
    def load_sounds(self):
        """Carga los sonidos del enemigo"""
        sounds = {
            "hit": pygame.mixer.Sound(os.path.join("assets", "sounds", "impact_sound.wav")),
            "death": pygame.mixer.Sound(os.path.join("assets", "sounds", "enemy_death_sound.wav"))
        }
        
        for sound in sounds.values():
            sound.set_volume(0.5)
        
        return sounds
    
    def take_damage(self, effects_group=None):
        """Reduce la vida del enemigo y muestra un efecto de impacto"""
        self.health -= 1
        print(f"¡El enemigo ha sido golpeado! Vida restante: {self.health}")

        if effects_group is not None:
            effect = HitEffect(self.rect.centerx, self.rect.centery)
            effects_group.add(effect)

        if self.health <= 0:
            print("¡El enemigo ha sido eliminado!")
            self.death_sound.play()
            self.kill()
            
    def update_animation(self):
        """Actualiza la animación del enemigo según su dirección y movimiento"""
        animation_key = f"walk_{self.direction}"  # Mapear la dirección a la clave de animación
        if animation_key in self.sprites and isinstance(self.sprites[animation_key], list):  # Verificar si existe
            self.frame_counter += self.animation_speed
            if self.frame_counter >= len(self.sprites[animation_key]):
                self.frame_counter = 0
            self.animation_index = int(self.frame_counter)
            self.image = self.sprites[animation_key][self.animation_index]
        else:
            self.image = self.sprites["idle"]  # Imagen estática si no hay animación

            
    def check_collision(self, dx, dy):
        """Verifica colisión con tiles sólidos"""
        new_rect = self.rect.move(dx, dy)
        return any(new_rect.colliderect(tile.rect) for tile in self.solid_tiles)
    
    def move(self, dx, dy):
        """Mueve al enemigo si no hay colisión"""
        if not self.check_collision(dx, dy):
            self.rect.x += dx
            self.rect.y += dy                            

    def update(self, player=None):
        """Actualizar la lógica del enemigo basado en su comportamiento"""
        if self.behavior and player:
            dx, dy, direction = self.behavior.update(self, player)
            self.rect.x += dx
            self.rect.y += dy
            self.direction = direction
            print(f"Enemy Update: dx={dx}, dy={dy}, direction={direction}")  # Depuración

        self.update_animation()




