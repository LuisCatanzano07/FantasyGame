import pygame
from src.config import SCREEN_WIDTH, SCREEN_HEIGHT, FPS
from src.core.scene_manager import SceneManager

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Fantasy Game")
        self.clock = pygame.time.Clock()
        self.running = True
        self.scene_manager = SceneManager(self)

    def handle_events(self):
        """Maneja eventos globales y los envía a la escena actual"""
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                self.running = False

        self.scene_manager.handle_events(events)

    def update(self):
        """Actualiza la escena actual"""
        self.scene_manager.update()

    def draw(self):
        """Dibuja la escena actual"""
        self.screen.fill((0, 0, 0))
        self.scene_manager.draw()
        pygame.display.flip()

    def run(self):
        """Bucle principal del juego"""
        while self.running:
            self.handle_events()
            self.update()
            self.draw()
            self.clock.tick(FPS)
        
        pygame.quit()


