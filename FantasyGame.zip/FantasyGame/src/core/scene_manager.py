class Scene:
    """Clase base para todas las escenas del juego"""
    def __init__(self, game):
        self.game = game
    
    def handle_events(self, events):
        """Maneja los eventos de la escena"""
        pass
    
    def update(self):
        """Actualiza la lógica de la escena"""
        pass
    
    def draw(self):
        """Dibuja la escena en pantalla"""
        pass


class SceneManager:
    """Gestiona las escenas del juego"""
    def __init__(self, game):
        self.game = game
        self.current_scene = None
    
    def set_scene(self, scene):
        """Cambia a una nueva escena asegurando que es una instancia válida"""
        if isinstance(scene, Scene):
            self.current_scene = scene
        else:
            raise TypeError("La escena debe ser una instancia de Scene")
    
    def get_scene(self):
        """Devuelve la escena actual"""
        return self.current_scene
    
    def clear_scene(self):
        """Limpia la escena actual"""
        self.current_scene = None
    
    def handle_events(self, events):
        """Delegar eventos a la escena actual"""
        if self.current_scene:
            self.current_scene.handle_events(events)
    
    def update(self):
        """Delegar actualización de la lógica a la escena actual"""
        if self.current_scene:
            self.current_scene.update()
    
    def draw(self):
        """Delegar el renderizado a la escena actual"""
        if self.current_scene:
            self.current_scene.draw()

