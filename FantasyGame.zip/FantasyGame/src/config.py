# src/config.py
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60
