import pygame
from src.entities.player.player import Player
from src.entities.map import Map
from src.entities.enemy.enemy import Enemy
from src.entities.enemy.behaviors import RandomMovement, ChasePlayer, PatrolBehavior
from src.core.scene_manager import Scene

class GameScene(Scene):
    """Escena principal del juego"""
    def __init__(self, game):
        super().__init__(game)
        self.map = Map()

        start_x, start_y = self.find_safe_spawn()
        self.player = Player(start_x, start_y, self.map.solid_tiles)

        self.all_sprites = pygame.sprite.Group()
        self.all_sprites.add(self.player)

        self.enemies = pygame.sprite.Group()
        self.effects = pygame.sprite.Group()
        
        self.spawn_enemies()
    
    def find_safe_spawn(self):
        """Busca la primera casilla libre (0) para colocar al jugador"""
        for row_index, row in enumerate(self.map.map_data):
            for col_index, tile in enumerate(row):
                if tile == 0:
                    return col_index * 100 + 25, row_index * 100 + 25
        return 100, 100
    
    def spawn_enemies(self):
        """Crea enemigos en posiciones seguras del mapa"""
        enemy_positions = [(300, 300), (500, 500), (700, 200)]
        behaviors = [RandomMovement(), ChasePlayer(), PatrolBehavior([(300, 300), (500, 500)])]
        
        for i, pos in enumerate(enemy_positions):
            tile_rect = pygame.Rect(pos[0], pos[1], 50, 50)
            if any(tile_rect.colliderect(tile.rect) for tile in self.map.solid_tiles):
                print(f"Posición {pos} bloqueada por un tile sólido. Moviendo enemigo.")
                continue

            behavior = behaviors[i % len(behaviors)]
            enemy = Enemy(pos[0], pos[1], behavior, self.map.solid_tiles)
            self.enemies.add(enemy)
            self.all_sprites.add(enemy)
        
    def handle_events(self, events):
        """Maneja eventos en la escena de juego"""
        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    from src.scenes.menu_scene import MenuScene
                    self.game.scene_manager.set_scene(MenuScene(self.game))
                elif event.key == pygame.K_SPACE:
                    if self.player.active_ability:
                        self.player.use_ability()
                    else:
                        self.player.attack(self.enemies, self.effects)
    
    def update(self):
        """Actualizar elementos del juego"""
        self.player.update()
        self.enemies.update(self.player)
        self.effects.update()
        self.player.projectiles.update()
        
        for projectile in self.player.projectiles:
            for enemy in self.enemies:
                if projectile.rect.colliderect(enemy.rect):
                    enemy.take_damage()
                    projectile.kill()

        if pygame.sprite.spritecollide(self.player, self.enemies, False):
            self.player.take_damage()

        if self.player.health <= 0:
            from src.scenes.menu_scene import MenuScene
            self.game.scene_manager.set_scene(MenuScene(self.game))

    def draw(self):
        """Dibuja el mapa, el jugador y los efectos"""
        self.game.screen.fill((0, 0, 0))
        self.map.draw(self.game.screen)
        self.all_sprites.draw(self.game.screen)
        self.effects.draw(self.game.screen)
        self.player.projectiles.draw(self.game.screen)
        self.player.draw_health_bar(self.game.screen)
        pygame.display.flip()














