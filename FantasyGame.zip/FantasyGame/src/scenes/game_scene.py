import pygame
from src.core.scene_manager import Scene
from src.entities.player import Player
from src.entities.map import Map
from src.entities.enemy import Enemy
from src.behaviors.enemy_behavior import RandomMovement, ChasePlayer, PatrolBehavior

class GameScene(Scene):
    """Escena principal del juego"""
    def __init__(self, game):
        super().__init__(game)
        self.map = Map()  # Cargar el mapa

        start_x, start_y = self.find_safe_spawn()
        self.player = Player(start_x, start_y, self.map.solid_tiles)

        self.all_sprites = pygame.sprite.Group()
        self.all_sprites.add(self.player)  # Solo se añade aquí al inicio

        self.enemies = pygame.sprite.Group()
        self.effects = pygame.sprite.Group()  # 🔥 Asegurar que `self.effects` no sea None
        
        self.spawn_enemies()
    
    def spawn_player(self):
        """Crea y posiciona al jugador en una zona segura"""
        start_x, start_y = self.find_safe_spawn()
        self.player = Player(start_x, start_y, self.map.solid_tiles)
        # Evitar añadir al grupo de nuevo si ya está incluido
        if self.player not in self.all_sprites:
            self.all_sprites.add(self.player)
    
    def find_safe_spawn(self):
        """Busca la primera casilla libre (0) para colocar al jugador"""
        for row_index, row in enumerate(self.map.map_data):
            for col_index, tile in enumerate(row):
                if tile == 0:
                    return col_index * 100 + 25, row_index * 100 + 25
        return 100, 100  # Valor por defecto si no se encuentra espacio
    
    def spawn_enemies(self):
        """Crea enemigos en posiciones seguras del mapa"""
        enemy_positions = [(300, 300), (500, 500), (700, 200)]
        behaviors = [RandomMovement(), ChasePlayer(), PatrolBehavior([(300, 300), (500, 500)])]

        for i, pos in enumerate(enemy_positions):
            # Verificar que la posición no esté en un tile sólido
            tile_rect = pygame.Rect(pos[0], pos[1], 50, 50)  # Tamaño de un enemigo
            if any(tile_rect.colliderect(tile.rect) for tile in self.map.solid_tiles):
                print(f"Posición {pos} bloqueada por un tile sólido. Moviendo enemigo.")
                continue  # Evitar colocar al enemigo aquí

            behavior = behaviors[i % len(behaviors)]  # Alternar entre comportamientos
            enemy = Enemy(pos[0], pos[1], behavior, self.map.solid_tiles)
            self.enemies.add(enemy)
            self.all_sprites.add(enemy)

    
    def handle_events(self, events):
        """Maneja eventos en la escena de juego"""
        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    from src.scenes.menu_scene import MenuScene
                    self.game.scene_manager.set_scene(MenuScene(self.game))
                elif event.key == pygame.K_SPACE:
                    print("¡Ataque activado!")
                    self.player.attack(self.enemies, self.effects)
    
    def update(self):
        """Actualizar elementos del juego"""
        self.player.update()
        self.enemies.update(self.player)
        self.effects.update()
        
        if pygame.sprite.spritecollide(self.player, self.enemies, False):
            self.player.take_damage()
        
        if self.player.health <= 0:
            print("¡Game Over!")
            from src.scenes.menu_scene import MenuScene
            self.game.scene_manager.set_scene(MenuScene(self.game))
    
    def draw(self):
        """Dibuja el mapa, el jugador y los efectos"""
        self.game.screen.fill((0, 0, 0))  # Limpiar la pantalla con un color negro
        self.map.draw(self.game.screen)  # Dibuja el mapa
        self.all_sprites.draw(self.game.screen)  # Dibuja el jugador y enemigos
        self.effects.draw(self.game.screen)  # Dibuja efectos como impactos
        self.player.draw_health_bar(self.game.screen)  # Dibuja la barra de vida
        pygame.display.flip()  # Actualizar la pantalla











