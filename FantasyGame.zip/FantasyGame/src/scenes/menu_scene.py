import pygame
from src.core.scene_manager import Scene

class MenuScene(Scene):
    """Escena de menú principal"""
    def __init__(self, game):
        super().__init__(game)
        self.font = pygame.font.Font(None, 50)
        self.text = self.create_text("Presiona ESPACIO para jugar")
    
    def create_text(self, message):
        """Crea una superficie de texto renderizada"""
        return self.font.render(message, True, (255, 255, 255))
    
    def handle_events(self, events):
        """Maneja eventos en el menú"""
        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    from src.scenes.game_scene import GameScene
                    self.game.scene_manager.set_scene(GameScene(self.game))
    
    def draw(self):
        """Dibuja el menú centrado en la pantalla"""
        screen_width, screen_height = self.game.screen.get_size()
        text_rect = self.text.get_rect(center=(screen_width // 2, screen_height // 2))
        
        self.game.screen.fill((0, 0, 0))  # Fondo negro
        self.game.screen.blit(self.text, text_rect)


