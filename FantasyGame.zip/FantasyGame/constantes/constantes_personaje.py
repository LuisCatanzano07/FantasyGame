import os
import pygame

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

# Ruta de los sprites del jugador
RUTA_SPRITES_JUGADOR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "assets", "sprites", "jugador"))


# Atributos base del personaje
SALUD_INICIAL = 100  # Salud con la que empieza el personaje
ENERGIA_INICIAL = 100  # Energía inicial para habilidades
DAÑO_INICIAL = 10  # Daño base del personaje
VELOCIDAD_MOVIMIENTO = 5  # Velocidad de desplazamiento
VELOCIDAD_SALTO = -15  # Fuerza del salto
GRAVEDAD = 1  # Valor de gravedad para caída

# Progresión del personaje
INCREMENTO_SALUD_NIVEL = 20  # Aumento de salud al subir de nivel
INCREMENTO_ENERGIA_NIVEL = 15  # Aumento de energía al subir de nivel
INCREMENTO_DAÑO_NIVEL = 2  # Aumento del daño al subir de nivel

# Sistema de experiencia y niveles
ENEMIGOS_PARA_SUBIR_NIVEL = 3  # Cantidad de enemigos que debe derrotar para subir de nivel

# Animaciones
TIEMPO_ANIMACION = 100  # Tiempo entre frames de animación (milisegundos)

# Configuración de habilidades
COSTO_ENERGIA_HABILIDAD = 20  # Energía requerida para lanzar una habilidad

# Límites de pantalla
LIMITE_IZQUIERDO = 0  # Límite izquierdo de la pantalla
LIMITE_DERECHO = 800  # Límite derecho de la pantalla (ajustable según tamaño de ventana)
LIMITE_SUELO = 500  # Posición del suelo en la pantalla

# Otros ajustes
TIEMPO_RECUPERACION = 2000  # Tiempo en milisegundos antes de que el jugador pueda volver a recibir daño
# Controles del personaje
TECLA_ESPEJAR = pygame.K_f
TECLA_SALTAR = pygame.K_w
