import os

# Ruta de los sprites del enemigo
RUTA_SPRITES_ENEMIGO = os.path.join("assets", "sprites", "enemigos")

# Atributos del enemigo
SALUD_INICIAL = 50  # Salud base
VELOCIDAD_MOVIMIENTO = 2  # Velocidad de patrulla y persecución
DANO_BASE = 5  # Daño que inflige al jugador
DEFENSA = 2  # Reducción de daño recibido
RANGO_VISION = 200  # Distancia a la que detecta al jugador

# Tiempo entre frames de animación (en milisegundos)
TIEMPO_ANIMACION = 100

