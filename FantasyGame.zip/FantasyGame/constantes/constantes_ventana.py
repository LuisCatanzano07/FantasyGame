# constantes/constantes_ventana.py

ANCHO_VENTANA = 800  # Ancho de la ventana
ALTO_VENTANA = 600   # Alto de la ventana
TITULO_VENTANA = "Fantasy Game"  # Título de la ventana
COLOR_FONDO = (0, 0, 0)  # Color de fondo (negro)
FPS = 60  # Fotogramas por segundo

